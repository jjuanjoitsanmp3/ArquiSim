# Proyecto final -- Filtros de imagen con ArquiSim
#
# El programa lee los botones UNA vez al empezar (palabra 0x600) y dibuja la imagen
# de .data con los filtros elegidos:
#
#   botón 0   filtro 1: negativo                 botón 7 = 0  pantalla de 16 colores:
#   botón 1   filtro 2: escala de grises                      original (x 0-15) | filtrada (x 16-31)
#   botón 2   filtro 3: el que proponga el grupo  botón 7 = 1  pantalla RGB 32 x 32:
#                                                             filtrada, cada píxel en 2 x 2
#
# Cómo probarlo:
#   (copie este archivo a la carpeta programas/ de su simulador)
#   ./sim -n 100000 programas/proyecto.asm
#   mem[0x600] = 0x81      activa los botones 0 y 7 (o use bt 0 y bt 7)
#   c                      ejecuta hasta el final;  p  cambia de pantalla
#   0                      reinicia: los botones se conservan para probar otra vez
#
# La imagen ocupa 0x200-0x2FF (16 x 16 bytes, RGB332 = RRRGGGBB). Para cambiarla,
# reemplace el bloque de abajo por la salida de img_a_arquisim (vea la sección
# "Preparar la imagen" del enunciado). El programa NO debe modificar la imagen.
#
# >>> IMAGEN (generado con: ./img_a_arquisim paisaje.bmp, a partir de paisaje_original.jpg)
# Imagen generada con img_a_arquisim a partir de 'paisaje.bmp' (480 x 480)
# 16 x 16 píxeles, 1 byte por píxel en formato RGB332 (RRRGGGBB) = 256 bytes
# El píxel (x, y) está en la dirección IMAGEN + 16*y + x
.data
IMAGEN:
        .byte 0x57, 0x57, 0x57, 0x57, 0x57, 0x57, 0x57, 0x57, 0x57, 0x57, 0x57, 0x57, 0x57, 0x57, 0x57, 0x57    # fila 0
        .byte 0x57, 0x57, 0x57, 0x57, 0x57, 0x57, 0x57, 0x57, 0x57, 0x57, 0x77, 0xB5, 0xD9, 0x96, 0x57, 0x57    # fila 1
        .byte 0x57, 0x57, 0x57, 0x57, 0x57, 0x57, 0x57, 0x57, 0x57, 0x57, 0xD9, 0xF8, 0xF8, 0xF8, 0x96, 0x57    # fila 2
        .byte 0x57, 0x57, 0x57, 0x57, 0x57, 0x57, 0x57, 0x57, 0x57, 0x77, 0xF8, 0xF8, 0xF8, 0xF8, 0xD9, 0x57    # fila 3
        .byte 0x57, 0x57, 0x57, 0x57, 0x77, 0x57, 0x57, 0x57, 0x57, 0x77, 0xF8, 0xF8, 0xF8, 0xF8, 0xB5, 0x57    # fila 4
        .byte 0x57, 0x57, 0x57, 0x77, 0xDB, 0x77, 0x57, 0x57, 0x57, 0x57, 0x96, 0xF8, 0xF8, 0xD9, 0x77, 0x57    # fila 5
        .byte 0x57, 0x57, 0x57, 0xBB, 0xDB, 0xBB, 0x57, 0x57, 0x57, 0x53, 0x57, 0x77, 0x77, 0x57, 0x57, 0x57    # fila 6
        .byte 0x57, 0x57, 0x72, 0x8D, 0x68, 0x8D, 0x72, 0x57, 0x53, 0x49, 0x49, 0x53, 0x57, 0x57, 0x57, 0x57    # fila 7
        .byte 0x57, 0x73, 0x69, 0x68, 0x68, 0x68, 0x69, 0x73, 0x49, 0x48, 0x48, 0x48, 0x4E, 0x57, 0x57, 0x57    # fila 8
        .byte 0x57, 0x6D, 0x68, 0x68, 0x68, 0x68, 0x68, 0x68, 0x48, 0x48, 0x48, 0x48, 0x48, 0x4D, 0x57, 0x57    # fila 9
        .byte 0x72, 0x6D, 0x68, 0x44, 0x48, 0x6D, 0x68, 0x48, 0x48, 0x48, 0x2C, 0x2C, 0x2C, 0x48, 0x49, 0x52    # fila 10
        .byte 0x35, 0x4D, 0x44, 0x44, 0x44, 0x4D, 0x35, 0x35, 0x35, 0x35, 0x2C, 0x2C, 0x2C, 0x35, 0x35, 0x35    # fila 11
        .byte 0x35, 0x6D, 0xC4, 0xC9, 0xC4, 0x6D, 0x35, 0x35, 0x35, 0x35, 0x31, 0x2C, 0x31, 0x35, 0x35, 0x35    # fila 12
        .byte 0x35, 0x6D, 0xC4, 0xF9, 0xC5, 0x6D, 0x35, 0x35, 0x35, 0x35, 0x35, 0x4C, 0x35, 0x35, 0x35, 0x35    # fila 13
        .byte 0x35, 0x51, 0x6D, 0x95, 0x6D, 0x51, 0x35, 0x35, 0x35, 0x35, 0x35, 0x51, 0x35, 0x35, 0x35, 0x35    # fila 14
        .byte 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35    # fila 15
# <<< IMAGEN

.text
# =====================================================================================
#  REGISTROS
#    Programa principal : $s0 = base de IMAGEN     $s1 = botones (se lee UNA vez, solo lectura después)
#                         $s2 = y                  $s3 = x            $s4 = píxel original
#                         $s5 = offset en pantalla de 16 colores      $s6 = base de la fila en IMAGEN
#    Funciones          : solo usan $a0 (argumento), $v0 (resultado), $t0-$t2 y $ra.
#                         FILTRAR lee $s1 pero NUNCA lo modifica.
#  FUNCIONES (todas: argumento en $a0 = píxel RGB332, resultado en $v0)
#    FILTRAR  aplica los filtros activados, en orden 1, 2, 3     (llama a GRIS: guarda $ra en la pila)
#    GRIS     píxel RGB332 -> píxel gris RGB332
#    A16      píxel RGB332 -> color 0-15 de la pantalla de 16 colores
#    ARGB     píxel RGB332 -> 0x00RRGGBB para la pantalla RGB
# =====================================================================================
main:   la    $s0, IMAGEN            # $s0 = dirección de la imagen (0x200)
        lw    $s1, 0x600($zero)      # $s1 = botones: se lee UNA sola vez
        andi  $t0, $s1, 0x80         # botón 7: 0 = 16 colores, 1 = RGB
        bne   $t0, $zero, RGB

# ---------------- Pantalla de 16 colores: original (x 0-15) | filtrada (x 16-31) ----------------
        add   $s2, $zero, $zero      # y = 0
Y16:    add   $s3, $zero, $zero      # x = 0
X16:    sll   $t0, $s2, 4            # t0 = 16*y
        add   $t0, $t0, $s3          #    + x
        add   $t0, $t0, $s0          #    + IMAGEN
        lbu   $s4, 0($t0)            # $s4 = píxel (x, y) sin signo
        sll   $s5, $s2, 5            # $s5 = 32*y + x = posición en la pantalla de 16 colores
        add   $s5, $s5, $s3
        add   $a0, $s4, $zero
        jal   A16                    # color del píxel original
        sb    $v0, 0x400($s5)        # mitad izquierda
        add   $a0, $s4, $zero
        jal   FILTRAR                # píxel filtrado
        add   $a0, $v0, $zero
        jal   A16
        sb    $v0, 0x410($s5)        # mitad derecha (x + 16)
        addi  $s3, $s3, 1
        slti  $t0, $s3, 16
        bne   $t0, $zero, X16
        addi  $s2, $s2, 1
        slti  $t0, $s2, 16
        bne   $t0, $zero, Y16
        j     FIN

# ---------------- Pantalla RGB 32 x 32: imagen filtrada ampliada 2 x 2 ----------------
RGB:    sw    $zero, 0x604($zero)    # posición inicial (0, 0): se escribe UNA vez
        add   $s2, $zero, $zero      # y = 0 (de 0 a 31)
YR:     srl   $s6, $s2, 1            # fila de la imagen = y / 2
        sll   $s6, $s6, 4
        add   $s6, $s6, $s0          # $s6 = dirección del inicio de esa fila
        add   $s3, $zero, $zero      # x = 0 (de 0 a 15: cada píxel se dibuja dos veces)
XR:     add   $t0, $s6, $s3
        lbu   $a0, 0($t0)
        jal   FILTRAR
        add   $a0, $v0, $zero
        jal   ARGB
        sw    $v0, 0x608($zero)      # 0x608 dibuja y avanza x: el píxel sale dos veces seguidas
        sw    $v0, 0x608($zero)      # (ancho 2); la fila se repite en y y y+1 (alto 2)
        addi  $s3, $s3, 1
        slti  $t0, $s3, 16
        bne   $t0, $zero, XR
        addi  $s2, $s2, 1
        slti  $t0, $s2, 32
        bne   $t0, $zero, YR
        j     FIN

# ---------------- FILTRAR: aplica los filtros activados, en orden ----------------
FILTRAR:
        addi  $sp, $sp, -4
        sw    $ra, 0($sp)            # se guarda $ra porque esta función llama a GRIS
        andi  $t0, $s1, 1            # botón 0: filtro 1, negativo
        beq   $t0, $zero, F2
        xori  $a0, $a0, 0xFF         # R' = 7-R, G' = 7-G, B' = 3-B: invertir los 8 bits
F2:     andi  $t0, $s1, 2            # botón 1: filtro 2, escala de grises
        beq   $t0, $zero, F3
        jal   GRIS
        add   $a0, $v0, $zero
F3:     andi  $t0, $s1, 4            # botón 2: filtro 3, SEPIA (ver informe)
        beq   $t0, $zero, FOUT
        jal   GRIS                   # sepia a partir de la luminosidad: Y = R del píxel gris
        srl   $t0, $v0, 5            # Y (0-7)
        addi  $t1, $t0, 1            # R' = Y + 1 ...
        slti  $t2, $t1, 8
        bne   $t2, $zero, SEP
        addi  $t1, $zero, 7          # ... saturado en 7
SEP:    sll   $a0, $t1, 5            # R' en los bits 7-5
        sll   $t2, $t0, 2            # G' = Y en los bits 4-2
        or    $a0, $a0, $t2
        srl   $t2, $t0, 2            # B' = Y / 4 (0 o 1) en los bits 1-0
        or    $a0, $a0, $t2
FOUT:   add   $v0, $a0, $zero
        lw    $ra, 0($sp)
        addi  $sp, $sp, 4
        jr    $ra

# ---------------- GRIS: Y = (R + 2G + 2B + 2) / 4 ; gris = (Y, Y, Y/2) ----------------
GRIS:   srl   $t0, $a0, 5            # R
        srl   $t1, $a0, 2
        andi  $t1, $t1, 7            # G
        andi  $t2, $a0, 3            # B
        add   $t1, $t1, $t2
        sll   $t1, $t1, 1            # 2G + 2B
        add   $t0, $t0, $t1
        addi  $t0, $t0, 2            # + 2 (redondeo)
        srl   $t0, $t0, 2            # Y = suma / 4 (0 a 7)
        sll   $v0, $t0, 5            # R' = Y
        sll   $t1, $t0, 2            # G' = Y
        or    $v0, $v0, $t1
        srl   $t1, $t0, 1            # B' = Y / 2
        or    $v0, $v0, $t1
        jr    $ra

# ---------------- A16: RGB332 -> color 0-15 (bit 0 rojo, 1 verde, 2 azul, 3 brillo) ----------------
A16:    srl   $v0, $a0, 7            # bit 0 (rojo)  = bit 7 del píxel
        srl   $t0, $a0, 3
        andi  $t1, $t0, 2            # bit 1 (verde) = bit 4 del píxel
        or    $v0, $v0, $t1
        or    $t0, $t0, $a0          # (p >> 3) | p
        andi  $t0, $t0, 8            # bit 3 (brillo) = bit 6 OR bit 3 del píxel
        or    $v0, $v0, $t0
        sll   $t0, $a0, 1
        andi  $t0, $t0, 4            # bit 2 (azul)  = bit 1 del píxel
        or    $v0, $v0, $t0
        jr    $ra

# ---------------- ARGB: RGB332 -> 0x00RRGGBB = (R << 21) | (G << 13) | (B << 6) ----------------
ARGB:   andi  $t0, $a0, 0xE0         # R sin mover: bits 7-5
        sll   $v0, $t0, 16           # (R << 5) << 16 = R << 21
        andi  $t0, $a0, 0x1C         # G sin mover: bits 4-2
        sll   $t0, $t0, 11           # (G << 2) << 11 = G << 13
        or    $v0, $v0, $t0
        andi  $t0, $a0, 3            # B
        sll   $t0, $t0, 6
        or    $v0, $v0, $t0
        jr    $ra

FIN:
