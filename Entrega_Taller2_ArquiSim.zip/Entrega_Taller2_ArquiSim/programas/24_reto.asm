# Programa 24 -- Reto final: contar los números negativos de un arreglo
#
#   int A[8] = {5, -3, 12, -7, 0, -1, 9, -20};
#   int NEGATIVOS;
#
#   int contar(int *a, int n) {          // $a0 = &a[0], $a1 = n, retorna en $v0
#       int c = 0;
#       for (; n > 0; n--, a++) if (*a < 0) c++;
#       return c;
#   }
#
#   NEGATIVOS = contar(A, 8);            // se guarda en .data con sw
#   for (x = 0; x < NEGATIVOS; x++)      // un píxel rojo por cada negativo, fila 0
#       pantalla[0][x] = rojo;
#
# Resultado esperado: NEGATIVOS = 4 (-3, -7, -1, -20) y 4 píxeles rojos en (0,0)..(3,0).
# Necesita: lw, sw, sb, slt, beq, j, jal, jr

.data
A:         .word 5, -3, 12, -7, 0, -1, 9, -20     # arreglo de 8 palabras desde 0x200
NEGATIVOS: .word 0                                # 0x220  (resultado)

.text
main:   la   $a0, A                   # $a0 = dirección del arreglo
        addi $a1, $zero, 8            # $a1 = tamaño
        jal  CONTAR                   # $v0 = cantidad de negativos
        sw   $v0, NEGATIVOS($zero)    # guardar el resultado en .data

        addi $s0, $zero, 0x400        # base de la pantalla: pixel (0, 0)
        addi $s1, $zero, 1            # color rojo
        add  $s2, $v0, $zero          # píxeles que faltan por pintar
PINTA:  beq  $s2, $zero, FIN
        sb   $s1, 0($s0)              # pintar el pixel (x, 0) de rojo
        addi $s0, $s0, 1              # siguiente pixel de la fila 0
        addi $s2, $s2, -1
        j    PINTA

# int contar(int *a, int n): cuenta los elementos menores que cero
CONTAR: add  $v0, $zero, $zero        # contador = 0
CLOOP:  beq  $a1, $zero, CRET         # ¿quedan elementos?
        lw   $t0, 0($a0)              # t0 = a[i]
        slt  $t1, $t0, $zero          # t1 = 1 si a[i] < 0
        add  $v0, $v0, $t1            # contador += t1
        addi $a0, $a0, 4              # siguiente palabra (4 bytes)
        addi $a1, $a1, -1
        j    CLOOP
CRET:   jr   $ra                      # volver con el resultado en $v0

FIN:
